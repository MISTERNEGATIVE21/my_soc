The goal of this package is to depend on everything that is (usually)
needed for running autogen/autoreconf if needed,
configure and make, but not a compiler.