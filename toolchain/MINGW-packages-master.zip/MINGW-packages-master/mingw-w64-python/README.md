The patches for this package are auto generated and managed in git:
https://github.com/msys2-contrib/cpython-mingw

Run `./update-patches.sh` to re-create the patches.
